// Synthesises a small, soft UI/motion SFX kit into public/sfx/*.wav (deterministic, no downloads).
// Kit: pop, click, whoosh, chime, thud. Every file is peak-normalised to the same level,
// then checked for length / peak / RMS / clipping.
import { writeFileSync, mkdirSync } from "node:fs";
const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url);
mkdirSync(OUT, { recursive: true });

let seed = 1234567;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 * 2 - 1; };
const N = (sec) => Math.floor(sec * SR);

const lowpass = (x, fc) => { const a = 1 - Math.exp(-2 * Math.PI * fc / SR); let y = 0; return x.map((v) => (y += a * (v - y))); };
const highpass = (x, fc) => { const lp = lowpass(x, fc); return x.map((v, i) => v - lp[i]); };
const fadeEnds = (x, inS, outS) => {
  const a = N(inS), b = N(outS);
  for (let i = 0; i < a && i < x.length; i++) x[i] *= i / a;
  for (let i = 0; i < b && i < x.length; i++) x[x.length - 1 - i] *= i / b;
  return x;
};
// very small "room": two quiet taps
const room = (x) => {
  const y = x.slice();
  for (const [d, g] of [[0.021, 0.16], [0.037, 0.09]]) {
    const o = N(d);
    for (let i = o; i < y.length; i++) y[i] += x[i - o] * g;
  }
  return y;
};

function pop() {
  const len = N(0.22); const x = new Array(len).fill(0); let ph = 0;
  for (let i = 0; i < len; i++) {
    const t = i / SR;
    const f = 140 + 300 * Math.exp(-t * 28);           // fast downward pitch drop
    ph += 2 * Math.PI * f / SR;
    const env = (1 - Math.exp(-t * 900)) * Math.exp(-t * 20); // soft attack, quick decay
    x[i] = Math.sin(ph) * env + rnd() * 0.04 * Math.exp(-t * 120);
  }
  return fadeEnds(room(lowpass(x, 5000)), 0.001, 0.03);
}
function click() {
  const len = N(0.07); const n = Array.from({ length: len }, rnd);
  const h = highpass(n, 2500);
  const x = h.map((v, i) => v * (1 - Math.exp(-(i / SR) * 1500)) * Math.exp(-(i / SR) * 110));
  return fadeEnds(lowpass(x, 7000), 0.0005, 0.01);
}
function whoosh() {
  const len = N(0.7); const n = Array.from({ length: len }, rnd);
  const x = new Array(len); let lp = 0, bp = 0;
  for (let i = 0; i < len; i++) {                      // band-pass noise sweep (state-variable filter)
    const t = i / len;
    const fc = 350 + 2200 * Math.sin(Math.PI * Math.min(1, t * 1.1)) ** 1.2;
    const f = 2 * Math.sin(Math.PI * fc / SR), q = 0.35;
    lp += f * bp; const hp = n[i] - lp - q * bp; bp += f * hp;
    x[i] = bp * Math.sin(Math.PI * t) ** 2;             // fade in / out
  }
  return fadeEnds(room(lowpass(x, 5500)), 0.01, 0.08);
}
function chime() {
  const len = N(0.5); const x = new Array(len).fill(0);
  const partials = [[880, 1, 7], [1320, 0.35, 9], [1760, 0.18, 12], [2217, 0.08, 16]];
  for (let i = 0; i < len; i++) {
    const t = i / SR; let s = 0;
    for (const [f, a, d] of partials) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t * d);
    x[i] = s * (1 - Math.exp(-t * 700));
  }
  return fadeEnds(room(lowpass(x, 5000)), 0.002, 0.06);
}
function thud() {
  const len = N(0.32); const x = new Array(len).fill(0); let ph = 0;
  for (let i = 0; i < len; i++) {
    const t = i / SR;
    ph += 2 * Math.PI * (46 + 40 * Math.exp(-t * 18)) / SR;
    x[i] = Math.sin(ph) * (1 - Math.exp(-t * 400)) * Math.exp(-t * 11);
  }
  return fadeEnds(lowpass(x, 400), 0.002, 0.05);
}

const TARGET_PEAK = 0.9;
const kit = { pop: pop(), click: click(), whoosh: whoosh(), chime: chime(), thud: thud() };
const LIMITS = { pop: 0.5, click: 0.5, whoosh: 0.8, chime: 0.5, thud: 0.5 };

for (const [name, raw] of Object.entries(kit)) {
  const peak0 = Math.max(...raw.map(Math.abs));
  const g = TARGET_PEAK / peak0;
  const x = raw.map((v) => v * g);
  const peak = Math.max(...x.map(Math.abs));
  const clipped = x.filter((v) => Math.abs(v) >= 0.999).length;
  const rms = Math.sqrt(x.reduce((s, v) => s + v * v, 0) / x.length);
  const dur = x.length / SR;
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  writeFileSync(new URL(name + ".wav", OUT), buf);
  const ok = dur <= LIMITS[name] && clipped === 0 && peak < 0.95;
  console.log(`${name.padEnd(7)} ${dur.toFixed(3)}s  peak ${peak.toFixed(3)}  rms ${rms.toFixed(3)}  clipped ${clipped}  ${ok ? "OK" : "CHECK"}`);
}
