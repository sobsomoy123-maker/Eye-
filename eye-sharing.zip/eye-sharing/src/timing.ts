// timing.ts — every time value derives from the SRT (src/cues.ts). Nothing is hand-placed.
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** Visuals land this many frames BEFORE the narration (4–6 frames). */
export const LEAD = 5;

/** absolute start / end frame of SRT cue i (1-based) */
export const cs = (i: number) => Math.round(cues[i - 1].start * FPS);
export const ce = (i: number) => Math.round(cues[i - 1].end * FPS);
/** cue length in frames */
export const dur = (i: number) => ce(i) - cs(i);
/** scene-local frame at which cue i's visual should enter */
export const o = (i: number, from: number, lead = LEAD) => cs(i) - lead - from;

export const TOTAL = ce(cues.length);

// Scenes break on cue boundaries (a scene may hold several cues).
export const SCENES = [
  { id: "hook", first: 1 },
  { id: "match", first: 3 },
  { id: "title", first: 6 },
  { id: "gaze", first: 9 },
  { id: "bond", first: 15 },
  { id: "fear", first: 17 },
  { id: "relief", first: 21 },
  { id: "reason", first: 24 },
  { id: "close", first: 26 },
] as const;

export const sceneRange = (k: number) => {
  const from = k === 0 ? 0 : cs(SCENES[k].first) - LEAD;
  const to = k === SCENES.length - 1 ? TOTAL : cs(SCENES[k + 1].first) - LEAD;
  return { from, to, length: to - from };
};

// Key moments (absolute frames) shared by scenes and the SFX track.
export const T = {
  // match scene: three rows appear at equal intervals across cue 3
  tick: [0, 1, 2].map((i) => cs(3) - LEAD + Math.round((i * dur(3)) / 3)),
  pill: cs(4) - LEAD,
  burst: cs(9) + Math.round(dur(9) * 0.55) - LEAD,
  lock: cs(11) - LEAD,
  rightPanel: cs(15) + Math.round(dur(15) * 0.55) - LEAD,
  barDone: cs(16) + Math.round(dur(16) * 0.5),
  bArrive: cs(21) + Math.round(dur(21) * 0.45),
  notAlone: cs(22) - LEAD,
  pair: cs(27) - LEAD,
  final: cs(28) - LEAD,
};
