import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  getRemotionEnvironment,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme } from "./theme";
import { cs } from "./timing";

export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/* ───────── Layer 1: background mesh + dust (persistent) ───────── */
export const Bg: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  // the "dawn" glow rises when the fear dissolves (cue 21–22) and stays to the end
  const dawn = interpolate(frame, [cs(21) - 10, cs(22) + 30], [0, 1], {
    ...CL,
    easing: theme.ease.inOut,
  });
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -520, left: -380 + d1, filter: "blur(50px)",
          background: `radial-gradient(circle, ${theme.colors.hero}33, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1000, height: 1000, borderRadius: "50%",
          bottom: -460, right: -300 - d2, filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.bgAlt}, transparent 65%)`,
        }}
      />
      <div
        style={{
          position: "absolute", left: width / 2 - 700, top: height / 2 - 500, width: 1400, height: 1000,
          opacity: dawn, filter: "blur(40px)",
          background: `radial-gradient(ellipse, ${theme.colors.accent}26, transparent 62%)`,
        }}
      />
      {Array.from({ length: 34 }).map((_, i) => {
        const x = random(`dx${i}`) * width;
        const y0 = random(`dy${i}`) * height;
        const sp = 0.12 + random(`ds${i}`) * 0.25;
        const y = (((y0 - frame * sp) % height) + height) % height;
        const r = 1.5 + random(`dr${i}`) * 2.5;
        const tw = 0.15 + 0.2 * (0.5 + 0.5 * Math.sin(frame / 38 + i));
        return (
          <div
            key={i}
            style={{
              position: "absolute", left: x, top: y, width: r * 2, height: r * 2,
              borderRadius: "50%", background: theme.colors.textDim, opacity: tw,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/* ───────── Layers 4–5: grade, grain, vignette (topmost) ───────── */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill
      style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06, mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)",
    }}
  />
);

/* ───────── Scene shell: fast exit (10f), faster than entrances ───────── */
export const Shell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = interpolate(frame, [durationInFrames - 10, durationInFrames - 1], [0, 1], {
    ...CL,
    easing: theme.ease.in,
  });
  return (
    <AbsoluteFill style={{ opacity: 1 - t, transform: `scale(${1 + t * 0.03}) translateY(${-t * 12}px)` }}>
      {children}
    </AbsoluteFill>
  );
};

/* ───────── Entrance wrapper: opacity + rise + scale ───────── */
export const Pop: React.FC<{
  delay: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
  exitAt?: number;
  cfg?: "smooth" | "snappy" | "bouncy";
}> = ({ delay, children, style, exitAt, cfg = "smooth" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring[cfg] });
  const ex = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + 8], [0, 1], { ...CL, easing: theme.ease.in });
  return (
    <div
      style={{
        opacity: Math.min(1, p) * (1 - ex),
        transform: `translateY(${interpolate(p, [0, 1], [40, 0]) - ex * 16}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/* ───────── Bangla-safe staggered word reveal (splits ONLY on spaces) ───────── */
export const Words: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  hl?: number[];
  hlColor?: string;
  underline?: number[];
  glow?: boolean;
  exitAt?: number;
  maxWidth?: number;
  align?: "center" | "flex-start";
  dim?: number;
}> = ({ text, delay = 0, per = 4, size, weight = 700, color, hl = [], hlColor, underline = [], glow = false, exitAt, maxWidth, align = "center", dim = 1 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const ex = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + 8], [0, 1], { ...CL, easing: theme.ease.in });
  return (
    <div
      style={{
        display: "flex", flexWrap: "wrap", justifyContent: align, columnGap: Math.round(size * 0.28),
        rowGap: Math.round(size * 0.04), maxWidth, fontFamily: theme.fonts.display, fontWeight: weight,
        fontSize: size, lineHeight: 1.35, letterSpacing: 0, color: color ?? theme.colors.text,
        opacity: (1 - ex) * dim, transform: `translateY(${-ex * 18}px)`, textAlign: "center",
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const up = spring({ frame: frame - delay - i * per - 8, fps, config: theme.spring.smooth });
        const isHl = hl.includes(i);
        return (
          <span
            key={i}
            style={{
              position: "relative", display: "inline-block", opacity: Math.min(1, p),
              transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
              color: isHl ? hlColor ?? theme.colors.accent : undefined,
              textShadow: isHl && glow ? `0 0 40px ${theme.colors.accent}66` : undefined,
            }}
          >
            {w}
            {underline.includes(i) && (
              <span
                style={{
                  position: "absolute", left: 0, right: 0, bottom: 2, height: 8, borderRadius: 8,
                  background: theme.colors.accent, opacity: 0.5, transformOrigin: "left",
                  transform: `scaleX(${Math.max(0, Math.min(1, up))})`,
                }}
              />
            )}
          </span>
        );
      })}
    </div>
  );
};

/** absolutely positioned horizontal band, content centred */
export const Band: React.FC<{ top: number; children: React.ReactNode; left?: number; right?: number }> = ({ top, children, left = 0, right = 0 }) => (
  <div style={{ position: "absolute", left, right, top, display: "flex", justifyContent: "center" }}>{children}</div>
);

/* ───────── The eye (SVG, gaze-driven, blinking) ───────── */
export const blink = (frame: number, times: number[]) =>
  times.reduce((m, t) => {
    const d = Math.abs(frame - t);
    return d < 4 ? Math.min(m, 0.08 + 0.92 * (d / 4)) : m;
  }, 1);

export const Eye: React.FC<{
  id: string;
  width: number;
  gx: number;
  gy: number;
  open?: number;
  iris?: string;
  glow?: boolean;
}> = ({ id, width, gx, gy, open = 1, iris = theme.colors.hero, glow = true }) => {
  const h = (width * 220) / 420;
  const cx = 210 + gx * 62;
  const cy = 110 + gy * 26;
  const almond = "M8,110 Q210,-30 412,110 Q210,250 8,110 Z";
  return (
    <svg
      width={width} height={h} viewBox="0 0 420 220"
      style={{ overflow: "visible", filter: glow ? `drop-shadow(0 0 28px ${theme.colors.glow})` : undefined }}
    >
      <defs>
        <clipPath id={`clip-${id}`}><path d={almond} /></clipPath>
      </defs>
      <g transform={`translate(0,110) scale(1,${Math.max(0.04, open)}) translate(0,-110)`}>
        <path d={almond} fill={theme.colors.sclera} />
        <g clipPath={`url(#clip-${id})`}>
          <circle cx={cx} cy={cy} r={64} fill={iris} />
          <circle cx={cx} cy={cy} r={64} fill="none" stroke={theme.colors.bg} strokeOpacity={0.35} strokeWidth={5} />
          <circle cx={cx} cy={cy} r={27} fill={theme.colors.bg} />
          <circle cx={cx - 17} cy={cy - 19} r={9} fill={theme.colors.text} opacity={0.92} />
          <path d={almond} fill="none" stroke="rgba(0,0,0,0.25)" strokeWidth={26} />
        </g>
        <path d={almond} fill="none" stroke={theme.colors.text} strokeWidth={7} strokeLinejoin="round" />
      </g>
    </svg>
  );
};

/* ───────── Sound: short, soft SFX clips ───────── */
// Per-clip gains compensate for their different RMS so all sit at one perceived level (~0.2–0.35).
export const SFX_LEVEL = { whoosh: 0.33, pop: 0.25, click: 0.33, chime: 0.3, thud: 0.2 } as const;
export const Sfx: React.FC<{
  at: number;
  name: keyof typeof SFX_LEVEL;
  vol?: number;
  rate?: number;
}> = ({ at, name, vol = 1, rate = 1 }) => (
  <Sequence from={Math.max(0, at)} durationInFrames={30} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={SFX_LEVEL[name] * vol} playbackRate={rate} />
  </Sequence>
);

/* ───────── Voiceover preview (Studio only; skipped silently if the file is absent) ───────── */
/** Preview switch. Rendering never includes it unless RENDER_WITH_VOICEOVER is true. */
export const PREVIEW_VOICEOVER = true;
export const RENDER_WITH_VOICEOVER = false;

export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const enabled = PREVIEW_VOICEOVER && (!isRendering || RENDER_WITH_VOICEOVER);
  const [ok, setOk] = React.useState(false);
  React.useEffect(() => {
    if (!enabled) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => alive && setOk(r.ok && /audio|mpeg|octet/.test(r.headers.get("content-type") ?? "")))
      .catch(() => alive && setOk(false));
    return () => { alive = false; };
  }, [enabled]);
  if (!enabled || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} />;
};
