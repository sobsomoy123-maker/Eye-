import React from "react";
import { interpolate, random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { T, ce, cs, dur, o } from "./timing";
import { Band, CL, Eye, Pop, Shell, Words, blink } from "./components";

type SP = { from: number };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const C = theme.colors;

/** spring that starts at scene-local frame `at` */
const useSp = (at: number, cfg: "smooth" | "snappy" | "bouncy" = "smooth") => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - at, fps, config: theme.spring[cfg] });
};

const Ring: React.FC<{ cx: number; cy: number; r0: number; r1: number; start: number; len?: number; color?: string; w?: number }> = ({ cx, cy, r0, r1, start, len = 40, color = C.accent, w = 4 }) => {
  const frame = useCurrentFrame();
  const t = interpolate(frame, [start, start + len], [0, 1], { ...CL, easing: theme.ease.out });
  const r = lerp(r0, r1, t);
  return (
    <div
      style={{
        position: "absolute", left: cx - r, top: cy - r, width: r * 2, height: r * 2, borderRadius: "50%",
        border: `${w}px solid ${color}`, opacity: frame < start ? 0 : (1 - t) * 0.9,
      }}
    />
  );
};

const Dot: React.FC<{ cx: number; cy: number; r: number; color?: string; glow?: boolean; opacity?: number }> = ({ cx, cy, r, color = C.hero, glow = true, opacity = 1 }) => (
  <div
    style={{
      position: "absolute", left: cx - r, top: cy - r, width: r * 2, height: r * 2, borderRadius: "50%",
      background: color, opacity, boxShadow: glow ? `0 0 ${r * 2.2}px ${color}99, 0 0 ${r * 4.4}px ${color}44` : undefined,
    }}
  />
);

const Glass: React.FC<{ style: React.CSSProperties; children?: React.ReactNode }> = ({ style, children }) => (
  <div
    style={{
      position: "absolute", borderRadius: theme.radius, background: C.glass, border: `1.5px solid ${C.line}`,
      boxShadow: `0 40px 80px -20px ${C.shadow}`, ...style,
    }}
  >
    {children}
  </div>
);

const Line: React.FC<{ x1: number; y1: number; x2: number; y2: number; p: number; color?: string; w?: number; dashed?: boolean }> = ({ x1, y1, x2, y2, p, color = C.hero, w = 6, dashed = false }) => {
  const len = Math.hypot(x2 - x1, y2 - y1);
  return (
    <svg style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }} width={1920} height={1080}>
      <line
        x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth={w} strokeLinecap="round"
        strokeDasharray={dashed ? "4 22" : len} strokeDashoffset={dashed ? 0 : len * (1 - Math.max(0, Math.min(1, p)))}
        opacity={dashed ? Math.max(0, Math.min(1, p)) : 1}
        style={dashed ? undefined : { filter: `drop-shadow(0 0 12px ${color})` }}
      />
    </svg>
  );
};

const Check: React.FC<{ p: number; size?: number }> = ({ p, size = 56 }) => (
  <svg width={size} height={size} viewBox="0 0 56 56" style={{ overflow: "visible" }}>
    <circle cx={28} cy={28} r={26} fill={C.hero} opacity={Math.min(1, p)} transform={`scale(${0.6 + 0.4 * Math.min(1, p)})`} style={{ transformOrigin: "28px 28px" }} />
    <path d="M16 29 L25 38 L41 19" fill="none" stroke={C.text} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.max(0, Math.min(1, (p - 0.3) / 0.7))} />
  </svg>
);

const Avatar: React.FC<{ size?: number }> = ({ size = 96 }) => (
  <svg width={size} height={size} viewBox="0 0 96 96">
    <circle cx={48} cy={48} r={46} fill={C.bgAlt} stroke={C.line} strokeWidth={2} />
    <circle cx={48} cy={38} r={15} fill={C.textDim} />
    <path d="M20 82 Q48 44 76 82 Z" fill={C.textDim} />
  </svg>
);

/* ═════════ 1 · HOOK (cues 1–2) — Kinetic type + Venn that pulls apart ═════════ */
export const Hook: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const enter = useSp(0);
  const t2 = o(2, from);
  const split = useSp(t2);
  const off = lerp(110, 330, split);
  const slide = interpolate(enter, [0, 1], [600, 0]);
  const strike = interpolate(frame, [t2 - 2, t2 + 14], [0, 1], { ...CL, easing: theme.ease.out });
  const bob = Math.sin(frame / 26) * 6;
  return (
    <Shell>
      <div
        style={{
          position: "absolute", left: 960 - off - slide - 210, top: 150 + bob, width: 420, height: 420, borderRadius: "50%",
          background: `${C.hero}66`, border: `3px solid ${C.hero}`, mixBlendMode: "screen", boxShadow: `0 0 80px ${C.glow}`,
        }}
      />
      <div
        style={{
          position: "absolute", left: 960 + off + slide - 210, top: 150 - bob, width: 420, height: 420, borderRadius: "50%",
          background: `${C.accent}4D`, border: `3px solid ${C.accent}`, mixBlendMode: "screen",
        }}
      />
      <Band top={640}>
        <div style={{ position: "relative", display: "inline-block" }}>
          <Words text="অনেক মিল থাকতে হবে" delay={8} size={88} maxWidth={1500} dim={interpolate(strike, [0, 1], [1, 0.35])} />
          <div
            style={{
              position: "absolute", left: -10, right: -10, top: "56%", height: 7, borderRadius: 7, background: C.accent,
              transformOrigin: "left", transform: `scaleX(${strike})`,
            }}
          />
        </div>
      </Band>
      <Band top={800}>
        <Words text="এমন কোনো কথা নেই।" delay={t2 + 2} size={124} color={C.accent} per={5} maxWidth={1600} glow />
      </Band>
    </Shell>
  );
};

/* ═════════ 2 · MATCH (cues 3–5) — twin profile cards, everything matches, no click ═════════ */
export const Match: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const labels = ["পছন্দ", "মতামত", "রুচি"];
  const tCards = 0;
  const t4 = o(4, from);
  const t5 = o(5, from);
  const cardsDim = interpolate(frame, [t5, t5 + 14], [1, 0.4], { ...CL, easing: theme.ease.out });
  const pillAppear = useSp(T.pill - from, "bouncy");
  const flick = 0.45 + 0.35 * Math.sin(frame / 3.1) * Math.sin(frame / 7.3);
  const cross = interpolate(frame, [t4 + 30, t4 + 42], [0, 1], { ...CL, easing: theme.ease.out });
  const solid = interpolate(frame, [t5, t5 + 22], [0, 1], { ...CL, easing: theme.ease.out });
  const pulseT = interpolate((frame - t5 - 14) % 46, [0, 46], [0, 1]);
  const cardY = (side: number) => 150 + Math.sin(frame / 34 + side) * 6;

  const Card: React.FC<{ x: number; side: number }> = ({ x, side }) => {
    const p = useSp(tCards + side * 4);
    return (
      <Glass
        style={{
          left: x, top: cardY(side), width: 600, height: 500, opacity: Math.min(1, p) * cardsDim,
          transform: `translateY(${interpolate(p, [0, 1], [50, 0])}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`,
        }}
      >
        <div style={{ position: "absolute", left: 252, top: 34 }}><Avatar /></div>
        {labels.map((l, i) => {
          const tr = T.tick[i] - from + side * 6;
          const lp = useSp(tr - 6, "snappy");
          const kp = useSp(tr, "bouncy");
          return (
            <div
              key={l}
              style={{
                position: "absolute", left: 56, right: 56, top: 164 + i * 104, height: 84, display: "flex",
                alignItems: "center", justifyContent: "space-between", padding: "0 30px", borderRadius: 24,
                background: "rgba(244,246,255,0.05)", opacity: Math.min(1, lp),
                transform: `translateX(${interpolate(lp, [0, 1], [side ? 40 : -40, 0])}px)`,
              }}
            >
              <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 48, color: C.text, letterSpacing: 0 }}>{l}</span>
              <Check p={kp} />
            </div>
          );
        })}
      </Glass>
    );
  };

  return (
    <Shell>
      <Card x={200} side={0} />
      <Card x={1120} side={1} />
      {/* connector between the two cards */}
      <Line x1={816} y1={400} x2={1104} y2={400} p={1 - solid} dashed color={C.textDim} w={6} />
      <Line x1={816} y1={400} x2={1104} y2={400} p={solid} color={C.hero} w={7} />
      {solid > 0.99 && (
        <>
          <div style={{ position: "absolute", left: lerp(816, 1104, pulseT) - 11, top: 389, width: 22, height: 22, borderRadius: "50%", background: C.accent, boxShadow: `0 0 24px ${C.accent}` }} />
          <div style={{ position: "absolute", left: lerp(1104, 816, pulseT) - 11, top: 389, width: 22, height: 22, borderRadius: "50%", background: C.accent, opacity: 0.55, boxShadow: `0 0 24px ${C.accent}` }} />
        </>
      )}
      {frame >= T.pill - from && frame < t5 + 10 && (
        <div
          style={{
            position: "absolute", left: 960 - 92, top: 400 - 38, width: 184, height: 76, borderRadius: 38,
            border: `3px dashed ${C.textDim}`, background: C.bg, display: "flex", alignItems: "center", justifyContent: "center",
            opacity: Math.min(1, pillAppear) * (cross > 0 ? 1 - 0.5 * cross : flick) * (1 - interpolate(frame, [t5, t5 + 10], [0, 1], CL)),
            transform: `scale(${interpolate(pillAppear, [0, 1], [0.6, 1])})`,
          }}
        >
          <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 40, color: C.textDim, letterSpacing: 0 }}>ক্লিক</span>
          <svg style={{ position: "absolute", left: 0, top: 0 }} width={184} height={76} viewBox="0 0 184 76">
            <path d="M18 62 L166 14" stroke={C.accent} strokeWidth={6} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - cross} />
          </svg>
        </div>
      )}
      <Band top={760}>
        <div style={{ position: "relative", height: 240, width: 1700 }}>
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
            <Words text="সবই হুবহু মেলে" delay={4} size={88} hl={[1]} exitAt={t4 - 8} />
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
            <Words text="তবুও কোথাও একটা ক্লিক করছে না" delay={t4} size={78} hl={[4]} exitAt={t5 - 8} />
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
            <Words text="যারা ঠিক আপনার মতো করে রিয়েক্ট করে" delay={t5} size={78} hl={[5]} underline={[5]} />
          </div>
        </div>
      </Band>
    </Shell>
  );
};

/* ═════════ 3 · TITLE (cues 6–8) — an eye opens, "Eye Sharing" lands ═════════ */
export const Title: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const t7 = o(7, from);
  const t8 = o(8, from);
  const open = useSp(t7, "smooth");
  const gaze = Math.sin(frame / 40) * 0.25;
  const bl = blink(frame, [t8 + 16]);
  const breathe = 1 + Math.sin(frame / 22) * 0.015;
  return (
    <Shell>
      <Band top={120}>
        <div style={{ display: "flex", gap: 28, alignItems: "center" }}>
          <Words text="একটা জিনিস আছে," delay={0} size={66} color={C.textDim} />
          <Words text="নাম—" delay={t7} size={66} color={C.textDim} />
        </div>
      </Band>
      <div style={{ position: "absolute", left: 960 - 280, top: 260, transform: `scale(${breathe})` }}>
        <Eye id="title" width={560} gx={gaze} gy={0} open={Math.min(1, open) * bl} />
      </div>
      <Ring cx={960} cy={406} r0={160} r1={520} start={t8} len={44} color={C.hero} />
      <Ring cx={960} cy={406} r0={160} r1={520} start={t8 + 8} len={44} color={C.accent} w={2} />
      <Band top={660}>
        <Words text="Eye Sharing" delay={t8} size={208} per={6} hl={[1]} glow />
      </Band>
    </Shell>
  );
};

/* ═════════ 4 · GAZE (cues 9–14) — two eyes search, then lock ═════════ */
export const Gaze: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const burst = T.burst - from;
  const lock = T.lock - from;
  const t10 = o(10, from);
  const t11 = o(11, from);
  const t12 = o(12, from);
  const t13 = o(13, from);
  const t14 = o(14, from);
  const eyeIn = [useSp(0), useSp(6)];
  const s1 = useSp(burst + 2, "snappy");
  const s2 = useSp(t10, "smooth");
  const s3 = useSp(lock, "snappy");
  const W = 480;
  const CY = 390;
  const xs = [470, 1450];
  const gazeOf = (side: 0 | 1) => {
    const dirIn = side === 0 ? 1 : -1; // toward the other eye
    const idle = { x: Math.sin(frame / 50 + side) * 0.25, y: Math.cos(frame / 61) * 0.2 };
    const look = { x: dirIn * 0.85, y: -0.1 };
    const scan = { x: Math.sin(frame / 11 + side * 2.1) * 0.95, y: Math.cos(frame / 14 + side) * 0.6 };
    const lk = { x: dirIn * 1.0, y: 0 };
    let gx = lerp(idle.x, look.x, s1);
    let gy = lerp(idle.y, look.y, s1);
    gx = lerp(gx, scan.x, s2); gy = lerp(gy, scan.y, s2);
    gx = lerp(gx, lk.x, s3); gy = lerp(gy, lk.y, s3);
    return { gx, gy };
  };
  const thread = interpolate(frame, [lock + 8, lock + 34], [0, 1], { ...CL, easing: theme.ease.out });
  const hum = 1 + Math.sin(frame / 12) * 0.12;
  const bl0 = blink(frame, [t12 + 20]);
  return (
    <Shell>
      {[0, 1].map((s) => {
        const g = gazeOf(s as 0 | 1);
        return (
          <div
            key={s}
            style={{
              position: "absolute", left: xs[s] - W / 2, top: CY - (W * 220) / 840,
              opacity: Math.min(1, eyeIn[s]),
              transform: `translateY(${interpolate(eyeIn[s], [0, 1], [40, 0]) + Math.sin(frame / 30 + s) * 4}px) scale(${interpolate(eyeIn[s], [0, 1], [0.9, 1])})`,
            }}
          >
            <Eye id={`gz${s}`} width={W} gx={g.gx} gy={g.gy} open={bl0} />
          </div>
        );
      })}
      {/* something odd happens: rings + rays burst from the middle */}
      <Ring cx={960} cy={CY} r0={10} r1={380} start={burst} len={36} color={C.accent} />
      <Ring cx={960} cy={CY} r0={10} r1={300} start={burst + 6} len={36} color={C.hero} />
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        {Array.from({ length: 12 }).map((_, i) => {
          const p = interpolate(frame, [burst + i * 1.2, burst + i * 1.2 + 22], [0, 1], { ...CL, easing: theme.ease.out });
          const a = (Math.PI * 2 * i) / 12;
          const r1 = 40 + p * 90;
          const r2 = 40 + p * 150;
          return (
            <line key={i} x1={960 + Math.cos(a) * r1} y1={CY + Math.sin(a) * r1} x2={960 + Math.cos(a) * r2} y2={CY + Math.sin(a) * r2}
              stroke={C.accent} strokeWidth={6} strokeLinecap="round" opacity={frame < burst ? 0 : 1 - p} />
          );
        })}
      </svg>
      {/* the thread between the two gazes */}
      <Line x1={470 + W / 2 + 14} y1={CY} x2={1450 - W / 2 - 14} y2={CY} p={thread} color={C.accent} w={6} />
      {thread > 0.98 && (
        <div style={{ position: "absolute", left: 960 - 16, top: CY - 16, width: 32, height: 32, borderRadius: "50%", background: C.accent, transform: `scale(${hum})`, boxShadow: `0 0 36px ${C.accent}` }} />
      )}
      <Band top={800}>
        <div style={{ position: "relative", height: 220, width: 1700 }}>
          {[
            { t: o(9, from), text: "অদ্ভুত কিছু ঘটে গেল", hl: [1], size: 84, exit: t10 - 8 },
            { t: t10, text: "চোখ দিয়ে খুঁজছেন এমন একজনকে", hl: [2], size: 78, exit: t11 - 8 },
            { t: t11, text: "সেও আপনার দিকেই তাকিয়ে আছে", hl: [3], size: 82, exit: t12 - 8 },
            { t: t12, text: "মাত্র এক সেকেন্ডের দৃষ্টি", hl: [2], size: 84, exit: t13 - 8 },
            { t: t13, text: "কোনো কথা নেই।", hl: [0, 1, 2], size: 120, exit: t14 - 8 },
            { t: t14, text: "আমরা একই জিনিস দেখেছি, একইভাবে অনুভব করেছি", hl: [3, 5], size: 66, exit: undefined },
          ].map((c, i) => (
            <div key={i} style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
              <Words text={c.text} delay={c.t} size={c.size} hl={c.hl} exitAt={c.exit} maxWidth={1600} glow={i === 4} />
            </div>
          ))}
        </div>
      </Band>
    </Shell>
  );
};

/* ═════════ 5 · BOND (cues 15–16) — hours of talk vs one glance ═════════ */
export const Bond: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const tR = T.rightPanel - from;
  const tDone = T.barDone - from;
  const t16 = o(16, from);
  const left = useSp(0);
  const right = useSp(tR);
  const lBar = interpolate(frame, [10, tR + 40], [0, 0.34], { ...CL, easing: theme.ease.inOut });
  const rBar = interpolate(frame, [tR + 10, tDone], [0, 1], { ...CL, easing: theme.ease.out });
  const hand = (frame / 14) * 60; // hours slipping by
  const bl = blink(frame, [tR + 50]);
  const Bar: React.FC<{ v: number; color: string; glow?: boolean }> = ({ v, color, glow }) => (
    <div style={{ position: "absolute", left: 70, right: 70, top: 436, display: "flex", flexDirection: "column", gap: 14 }}>
      <span style={{ fontFamily: theme.fonts.display, fontWeight: 500, fontSize: 38, color: C.textDim, letterSpacing: 0 }}>বন্ধন</span>
      <div style={{ height: 26, borderRadius: 13, background: "rgba(244,246,255,0.08)", overflow: "hidden" }}>
        <div style={{ width: `${v * 100}%`, height: "100%", borderRadius: 13, background: color, boxShadow: glow ? `0 0 28px ${color}` : undefined }} />
      </div>
    </div>
  );
  return (
    <Shell>
      <Glass
        style={{
          left: 110, top: 130, width: 790, height: 560, opacity: Math.min(1, left),
          transform: `translateY(${interpolate(left, [0, 1], [50, 0])}px) scale(${interpolate(left, [0, 1], [0.94, 1])})`,
        }}
      >
        <div style={{ position: "absolute", left: 0, right: 0, top: 36, display: "flex", justifyContent: "center" }}>
          <Words text="ঘণ্টার পর ঘণ্টা কথা" delay={4} size={60} color={C.text} maxWidth={700} />
        </div>
        <svg style={{ position: "absolute", left: 295, top: 170, overflow: "visible" }} width={200} height={200} viewBox="0 0 200 200">
          <circle cx={100} cy={100} r={90} fill="none" stroke={C.textDim} strokeWidth={6} />
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={i} x1={100} y1={18} x2={100} y2={i % 3 === 0 ? 34 : 27} stroke={C.textDim} strokeWidth={4} strokeLinecap="round" transform={`rotate(${i * 30} 100 100)`} />
          ))}
          <line x1={100} y1={100} x2={100} y2={34} stroke={C.text} strokeWidth={6} strokeLinecap="round" transform={`rotate(${hand} 100 100)`} />
          <line x1={100} y1={100} x2={100} y2={56} stroke={C.textDim} strokeWidth={8} strokeLinecap="round" transform={`rotate(${hand / 12} 100 100)`} />
        </svg>
        <Bar v={lBar} color={C.textDim} />
      </Glass>
      <Glass
        style={{
          left: 1020, top: 130, width: 790, height: 560, opacity: Math.min(1, right),
          transform: `translateY(${interpolate(right, [0, 1], [50, 0])}px) scale(${interpolate(right, [0, 1], [0.94, 1])})`,
          borderColor: `${C.hero}AA`, boxShadow: `0 40px 80px -20px ${C.shadow}, 0 0 90px ${C.glow}`,
        }}
      >
        <div style={{ position: "absolute", left: 0, right: 0, top: 36, display: "flex", justifyContent: "center" }}>
          <Words text="এক পলকের বোঝাপড়া" delay={tR + 4} size={60} color={C.text} maxWidth={700} />
        </div>
        <div style={{ position: "absolute", left: 255, top: 210 }}>
          <Eye id="bond" width={280} gx={-0.1} gy={0} open={bl} />
        </div>
        <Bar v={rBar} color={C.hero} glow />
      </Glass>
      <Band top={800}>
        <Words text="সেটা তৈরি করে দেয়।" delay={t16} size={110} hl={[2, 3]} glow />
      </Band>
    </Shell>
  );
};

/* ═════════ 6 · FEAR (cues 17–20) — one dot alone inside a mind ═════════ */
export const Fear: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const t18 = o(18, from);
  const t19 = o(19, from);
  const t20 = o(20, from);
  const ringIn = useSp(t18 - 6);
  const shrink = useSp(t20, "smooth");
  const dotR = lerp(22, 13, shrink);
  const dotO = lerp(1, 0.55, shrink);
  const wob = Math.sin(frame / 18) * 10;
  const cx = 560;
  const cy = 540;
  const pulse = (k: number) => (((frame - t18 - k * 40) % 120) + 120) % 120;
  return (
    <Shell>
      <Band top={380}>
        <Words text="কেন এমন হয়?" delay={0} size={170} per={6} hl={[1]} glow exitAt={t18 - 10} />
      </Band>
      <div style={{ opacity: Math.min(1, ringIn), transform: `scale(${interpolate(ringIn, [0, 1], [0.85, 1])})` }}>
        <div style={{ position: "absolute", left: cx - 270, top: cy - 270, width: 540, height: 540, borderRadius: "50%", border: `3px dashed ${C.line}`, background: "rgba(7,10,28,0.45)", boxShadow: "inset 0 0 120px rgba(0,0,0,0.5)" }} />
        {[0, 1, 2].map((k) => {
          const p = pulse(k) / 120;
          const r = lerp(24, 255, p);
          return frame > t18 + k * 40 ? (
            <div key={k} style={{ position: "absolute", left: cx + wob * 0.4 - r, top: cy - r, width: r * 2, height: r * 2, borderRadius: "50%", border: `3px solid ${C.hero}`, opacity: (1 - p) * 0.55 * dotO }} />
          ) : null;
        })}
        <Dot cx={cx + wob * 0.4} cy={cy + Math.sin(frame / 23) * 8} r={dotR} opacity={dotO} />
      </div>
      <div style={{ position: "absolute", left: 960, top: 250, width: 880 }}>
        <div style={{ position: "absolute", left: 0, top: 0, width: 880, display: "flex", justifyContent: "flex-start" }}>
          <Words text="মনের গভীরে চাপা ভয়" delay={t18} size={60} color={C.textDim} align="flex-start" maxWidth={880} />
        </div>
        <div style={{ position: "absolute", left: 0, top: 120, width: 880, display: "flex" }}>
          <Words text="কেউ কি আমার মতো করে দুনিয়াটাকে দেখে?" delay={t19} size={72} align="flex-start" maxWidth={880} hl={[5]} />
        </div>
        <div style={{ position: "absolute", left: 0, top: 380, width: 880, display: "flex" }}>
          <Words text="মাথার ভেতরে বড্ড একা?" delay={t20} size={84} align="flex-start" maxWidth={880} hl={[3]} glow />
        </div>
      </div>
    </Shell>
  );
};

/* ═════════ 7 · RELIEF (cues 21–23) — a second dot answers; the fear dissolves ═════════ */
export const Relief: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const t21 = o(21, from);
  const t22 = o(22, from);
  const t23 = o(23, from);
  const tB = T.bArrive - from;
  const aIn = useSp(0, "bouncy");
  const bIn = useSp(tB, "bouncy");
  const line = interpolate(frame, [t22, t22 + 26], [0, 1], { ...CL, easing: theme.ease.out });
  const ax = 640;
  const bx = 1280;
  const y = 400;
  const fade = interpolate(frame, [t21, t21 + 40], [0, 1], { ...CL, easing: theme.ease.out });
  return (
    <Shell>
      {/* fear particles scatter outward and vanish */}
      {Array.from({ length: 26 }).map((_, i) => {
        const a = random(`fa${i}`) * Math.PI * 2;
        const r0 = 40 + random(`fr${i}`) * 140;
        const r = r0 + fade * (220 + random(`fs${i}`) * 260);
        const s = 5 + random(`fz${i}`) * 9;
        return (
          <div key={i} style={{ position: "absolute", left: 960 + Math.cos(a) * r - s, top: y + Math.sin(a) * r * 0.62 - s, width: s * 2, height: s * 2, borderRadius: "50%", background: C.textDim, opacity: (1 - fade) * 0.5 * Math.min(1, aIn) }} />
        );
      })}
      <Ring cx={ax} cy={y} r0={20} r1={300} start={4} len={50} color={C.hero} />
      <Ring cx={ax} cy={y} r0={20} r1={420} start={30} len={60} color={C.hero} w={2} />
      <Ring cx={bx} cy={y} r0={20} r1={300} start={tB + 4} len={50} color={C.accent} />
      <Line x1={ax + 26} y1={y} x2={bx - 26} y2={y} p={line} color={C.accent} w={6} />
      <Dot cx={ax} cy={y} r={26 * Math.min(1.1, aIn)} />
      <Dot cx={bx} cy={y} r={26 * Math.min(1.1, bIn)} color={C.accent} opacity={Math.min(1, bIn)} />
      <Band top={640}>
        <div style={{ position: "relative", height: 330, width: 1700 }}>
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
            <Words text="ভয়টা নিমেষে মিলিয়ে যায়" delay={t21} size={80} exitAt={t22 - 8} hl={[2, 3]} />
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
            <Words text="আমি একা নই।" delay={t22} size={150} per={6} hl={[1, 2]} glow />
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, top: 190, display: "flex", justifyContent: "center" }}>
            <Words text="কেউ একজন আমার চোখ দিয়েই সবকিছু দেখে" delay={t23} size={60} color={C.textDim} maxWidth={1600} />
          </div>
        </div>
      </Band>
    </Shell>
  );
};

/* ═════════ 8 · REASON (cues 24–25) — a calm statement card with two small eyes ═════════ */
export const Reason: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const t25 = o(25, from);
  const card = useSp(0);
  const eyes = useSp(6);
  const bl = blink(frame, [60, 150]);
  const gz = interpolate(useSp(16, "smooth"), [0, 1], [0, 1]);
  return (
    <Shell>
      {[0, 1].map((s) => (
        <div key={s} style={{ position: "absolute", left: (s ? 1120 : 800) - 140, top: 150, opacity: Math.min(1, eyes), transform: `translateY(${interpolate(eyes, [0, 1], [30, 0]) + Math.sin(frame / 30 + s) * 4}px)` }}>
          <Eye id={`rs${s}`} width={280} gx={(s ? -1 : 1) * gz * 0.9} gy={0} open={bl} />
        </div>
      ))}
      <Glass
        style={{
          left: 260, top: 380, width: 1400, height: 500, opacity: Math.min(1, card),
          transform: `translateY(${interpolate(card, [0, 1], [50, 0])}px) scale(${interpolate(card, [0, 1], [0.95, 1])})`,
        }}
      >
        <div style={{ position: "absolute", left: 0, right: 0, top: 50, display: "flex", justifyContent: "center" }}>
          <Words text="সেরা বন্ধুত্বের কোনো যুক্তি দিয়ে ব্যাখ্যা হয় না" delay={4} size={76} maxWidth={1200} hl={[0, 1]} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 310, display: "flex", justifyContent: "center" }}>
          <Words text="কোনো কারণ ছাড়াই একে অপরকে বোঝেন" delay={t25} size={62} color={C.textDim} maxWidth={1200} hl={[0, 1, 2]} hlColor={C.accent} underline={[0, 1, 2]} />
        </div>
      </Glass>
    </Shell>
  );
};

/* ═════════ 9 · CLOSE (cues 26–28) — many eyes look different ways; one pair finds each other ═════════ */
export const Close: React.FC<SP> = ({ from }) => {
  const frame = useCurrentFrame();
  const t27 = T.pair - from;
  const t28 = T.final - from;
  const pair = useSp(t27, "smooth");
  const lockG = useSp(t27 + 6, "snappy");
  const thread = interpolate(frame, [t28, t28 + 26], [0, 1], { ...CL, easing: theme.ease.out });
  const pairIdx = [6, 8];
  const targets = [{ x: 690, y: 400 }, { x: 1230, y: 400 }];
  return (
    <Shell>
      {Array.from({ length: 10 }).map((_, i) => {
        const col = i % 5;
        const row = Math.floor(i / 5);
        const gx0 = 960 + (col - 2) * 340;
        const gy0 = 240 + row * 220;
        const pi = pairIdx.indexOf(i);
        const isPair = pi >= 0;
        const ein = useSp(((i * 7) % 10) * 3, "smooth");
        const ang = random(`ga${i}`) * Math.PI * 2 + frame / (70 + i * 6);
        const rg = { x: Math.cos(ang) * 0.9, y: Math.sin(ang) * 0.6 };
        const width = isPair ? lerp(220, 340, pair) : 220;
        const x = isPair ? lerp(gx0, targets[pi].x, pair) : gx0;
        const y = isPair ? lerp(gy0, targets[pi].y, pair) : gy0;
        const g = isPair ? { x: lerp(rg.x, pi === 0 ? 1 : -1, lockG), y: lerp(rg.y, 0, lockG) } : rg;
        const dim = isPair ? 1 : lerp(1, 0.1, pair);
        const bl = blink(frame, [40 + i * 17, 200 + i * 23]);
        return (
          <div key={i} style={{ position: "absolute", left: x - width / 2, top: y - (width * 220) / 840, opacity: Math.min(1, ein) * dim, transform: `scale(${interpolate(ein, [0, 1], [0.8, 1])})` }}>
            <Eye id={`cl${i}`} width={width} gx={g.x} gy={g.y} open={bl} glow={isPair} iris={isPair ? C.hero : C.textDim} />
          </div>
        );
      })}
      <Line x1={690 + 190} y1={400} x2={1230 - 190} y2={400} p={thread} color={C.accent} w={6} />
      <Band top={760}>
        <div style={{ position: "relative", height: 260, width: 1700 }}>
          {[
            { t: 4, text: "সবাই হয়তো আপনার মতো করে দুনিয়াকে দেখবে না", size: 66, hl: [], exit: t27 - 8 },
            { t: t27, text: "এমন একজনকে পাওয়া, যে ঠিক আপনার চোখ দিয়েই পৃথিবীটা দেখে", size: 66, hl: [4, 8], exit: t28 - 8 },
            { t: t28, text: "সেটাই হয়তো সত্যিকারের বন্ধুত্ব", size: 104, hl: [2, 3], exit: undefined },
          ].map((c, i) => (
            <div key={i} style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center" }}>
              <Words text={c.text} delay={c.t} size={c.size} hl={c.hl} exitAt={c.exit} maxWidth={1600} glow={i === 2} />
            </div>
          ))}
        </div>
      </Band>
    </Shell>
  );
};

export const SCENE_COMPONENTS: Record<string, React.FC<SP>> = {
  hook: Hook, match: Match, title: Title, gaze: Gaze, bond: Bond, fear: Fear, relief: Relief, reason: Reason, close: Close,
};
// kept for lint: these timing helpers are re-exported for scene authors
export const _timing = { ce, cs, dur };
