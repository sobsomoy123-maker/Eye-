import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { Bg, Grade, Grain, PreviewAudio, Sfx, Vignette } from "./components";
import { SCENE_COMPONENTS } from "./scenes";
import { LEAD, SCENES, T, cs, sceneRange } from "./timing";

/** Every sound is placed from the same timing table as the visuals (2–3 frames before the hit). */
const SfxTrack: React.FC = () => {
  const whooshRates = [1, 0.94, 1.06, 0.97, 1.04, 0.92, 1.02, 0.96];
  return (
    <>
      {/* hook: one very soft thud */}
      <Sfx at={2} name="thud" vol={0.8} />
      {/* scene transitions: short smooth whoosh (slightly varied) */}
      {SCENES.slice(1).map((_, k) => (
        <Sfx key={k} at={sceneRange(k + 1).from - 4} name="whoosh" rate={whooshRates[k % whooshRates.length]} vol={0.9 + (k % 3) * 0.08} />
      ))}
      {/* match: ticks on the three matching rows, then the "click" pill */}
      {T.tick.map((t, i) => (
        <Sfx key={i} at={t - 2} name="click" rate={1 + i * 0.06} vol={0.9 - i * 0.05} />
      ))}
      <Sfx at={T.pill - 2} name="pop" rate={0.95} vol={0.8} />
      {/* title: eye opens, then "Eye Sharing" lands */}
      <Sfx at={cs(7) - LEAD - 2} name="pop" rate={1.05} />
      <Sfx at={cs(8) - LEAD - 2} name="chime" />
      {/* gaze: odd event, then the lock */}
      <Sfx at={T.burst - 2} name="pop" rate={1.1} />
      <Sfx at={T.lock - 2} name="chime" rate={1.12} vol={0.9} />
      <Sfx at={T.lock - 2} name="thud" vol={0.6} />
      {/* bond */}
      <Sfx at={T.rightPanel - 2} name="pop" rate={1.0} />
      <Sfx at={T.barDone - 2} name="chime" rate={1.2} vol={0.85} />
      {/* relief */}
      <Sfx at={T.bArrive - 2} name="pop" rate={1.08} />
      <Sfx at={T.notAlone - 2} name="chime" rate={0.94} />
      {/* reason */}
      <Sfx at={sceneRange(7).from + 4} name="pop" rate={0.97} vol={0.85} />
      {/* close */}
      <Sfx at={T.pair - 2} name="pop" rate={1.04} />
      <Sfx at={T.final - 2} name="chime" rate={0.9} vol={0.95} />
    </>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Bg />
    {SCENES.map((s, k) => {
      const { from, length } = sceneRange(k);
      const Scene = SCENE_COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={from} durationInFrames={length} name={s.id}>
          <Scene from={from} />
        </Sequence>
      );
    })}
    <SfxTrack />
    <PreviewAudio />
    <Grade />
    <Grain />
    <Vignette />
  </AbsoluteFill>
);
