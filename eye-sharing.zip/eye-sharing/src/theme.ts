// theme.ts — single source of truth: colors, fonts, easings, spring presets.
// Colour scheme: "মধ্যরাতের নীল" (Midnight Blue).
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const { fontFamily } = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin"],
});

export const theme = {
  colors: {
    bg: "#0B1026",
    bgAlt: "#141C3E",
    hero: "#5B7CFA",
    accent: "#FFC857",
    text: "#F4F6FF",
    textDim: "#9AA5D4",
    sclera: "#EAF0FF",
    glow: "rgba(91, 124, 250, 0.45)",
    glass: "rgba(244, 246, 255, 0.06)",
    line: "rgba(244, 246, 255, 0.16)",
    shadow: "rgba(0, 0, 0, 0.45)",
  },
  fonts: { display: `${fontFamily}, "Hind Siliguri", sans-serif` },
  radius: 36,
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
