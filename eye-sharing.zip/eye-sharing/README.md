# Eye Sharing — Remotion project
1. `npm install`
2. `npx remotion studio`          (Composition: Main, 1920x1080, 30fps)
3. `npx remotion render src/index.ts Main out/video.mp4`

- Timing comes only from `script/eye_sharing.srt` → `npm run cues` regenerates `src/cues.ts`.
- Put `public/voiceover.mp3` to hear the voiceover in Studio (flags in `src/components.tsx`).
- `npm run sfx` regenerates the SFX in `public/sfx/`.
- Font (Hind Siliguri) loads via @remotion/google-fonts — needs internet on first run.
